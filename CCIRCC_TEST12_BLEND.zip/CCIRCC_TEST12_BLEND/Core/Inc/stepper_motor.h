#ifndef __STEPPER_MOTOR_H
#define __STEPPER_MOTOR_H



#include "stm32f1xx_hal.h"

// ���������
#define MOTOR_FORWARD  0
#define MOTOR_REVERSE  1

typedef struct {
    GPIO_TypeDef* enable_port;
    uint16_t enable_pin;
    GPIO_TypeDef* step_port;
    uint16_t step_pin;
    GPIO_TypeDef* dir_port;
    uint16_t dir_pin;
} StepperMotor;

// ��ʼ������
void Stepper_Init(StepperMotor *motor,
                 GPIO_TypeDef* enable_port, uint16_t enable_pin,
                 GPIO_TypeDef* step_port, uint16_t step_pin,
                 GPIO_TypeDef* dir_port, uint16_t dir_pin);

// ��������
void Stepper_Enable(StepperMotor *motor);
void Stepper_Disable(StepperMotor *motor);

// ��������ת�ӿ�
void Stepper_Run(StepperMotor *motor, uint8_t direction, uint32_t steps);



#endif /* __STEPPER_MOTOR_H */
