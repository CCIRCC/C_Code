/* valuepack_hal.c */
#include "valuepack_hal.h"
unsigned char bits[] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};

const unsigned int VALUEPACK_INDEX_RANGE=VALUEPACK_BUFFER_SIZE<<3; 
const unsigned short  TXPACK_BYTE_SIZE = ((TX_BOOL_NUM+7)>>3)+TX_BYTE_NUM+(TX_SHORT_NUM<<1)+(TX_INT_NUM<<2)+(TX_FLOAT_NUM<<2);
const unsigned short  RXPACK_BYTE_SIZE = ((RX_BOOL_NUM+7)>>3)+RX_BYTE_NUM+(RX_SHORT_NUM<<1)+(RX_INT_NUM<<2)+(RX_FLOAT_NUM<<2);
unsigned short rx_pack_length = RXPACK_BYTE_SIZE+3;


long rxIndex=0;
long rdIndex=0;


unsigned char vp_rxbuff[VALUEPACK_BUFFER_SIZE];
unsigned char vp_txbuff[TXPACK_BYTE_SIZE+3];


DMA_InitTypeDef dma;
unsigned short this_index=0;
unsigned short last_index=0;
unsigned short rdi,rdii,idl,idi;
uint32_t  idc;
unsigned int err=0;
unsigned char sum=0;
unsigned char isok;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//procValuePack ���������ֻ�����������
//

unsigned char readValuePack(RxPack *rx_pack_ptr)
{
	isok = 0;	
	this_index =VALUEPACK_BUFFER_SIZE-DMA1_Channel5->CNDTR;
	if(this_index<last_index)
		rxIndex+=VALUEPACK_BUFFER_SIZE+this_index-last_index;
	else
		rxIndex+=this_index-last_index;
	while(rdIndex<(rxIndex-((rx_pack_length))))
   rdIndex+=rx_pack_length;	
	while(rdIndex<=(rxIndex-rx_pack_length))
	{
		
		rdi = rdIndex % VALUEPACK_BUFFER_SIZE;
		rdii=rdi+1;
		if( vp_rxbuff[rdi]==PACK_HEAD)
		{
			if(vp_rxbuff[(rdi+RXPACK_BYTE_SIZE+2)%VALUEPACK_BUFFER_SIZE]==PACK_TAIL)
			{
				//  ����У���
				sum=0;
			  for(short s=0;s<RXPACK_BYTE_SIZE;s++)
				{
					rdi++;
					if(rdi>=VALUEPACK_BUFFER_SIZE)
					  rdi -= VALUEPACK_BUFFER_SIZE;
					sum += vp_rxbuff[rdi];
				}	
						rdi++;
					if(rdi>=VALUEPACK_BUFFER_SIZE)
					  rdi -= VALUEPACK_BUFFER_SIZE;
					
        if(sum==vp_rxbuff[rdi]) 
				{
					//  ��ȡ���ݰ����� һ�����岽�� bool byte short int float
					
					// 1. bool
					#if  RX_BOOL_NUM>0
					
						idc = (uint32_t)rx_pack_ptr->bools;
					  idl = (RX_BOOL_NUM+7)>>3;
					  for(idi=0;idi<idl;idi++)
					  {
					    if(rdii>=VALUEPACK_BUFFER_SIZE)
					      rdii -= VALUEPACK_BUFFER_SIZE;
					   (*((unsigned char *)idc))= vp_rxbuff[rdii];
							rdii++;
							idc++;
					  }
				  #endif
					// 2.byte
					#if RX_BYTE_NUM>0
						idc = (uint32_t)(rx_pack_ptr->bytes);
					  idl = RX_BYTE_NUM;
					  for(idi=0;idi<idl;idi++)
					  {
					    if(rdii>=VALUEPACK_BUFFER_SIZE)
					      rdii -= VALUEPACK_BUFFER_SIZE;
					    (*((unsigned char *)idc))= vp_rxbuff[rdii];
							rdii++;
							idc++;
					  }
				  #endif
					// 3.short
					#if RX_SHORT_NUM>0
						idc = (uint32_t)(rx_pack_ptr->shorts);
					  idl = RX_SHORT_NUM<<1;
					  for(idi=0;idi<idl;idi++)
					  {
					    if(rdii>=VALUEPACK_BUFFER_SIZE)
					      rdii -= VALUEPACK_BUFFER_SIZE;
					    (*((unsigned char *)idc))= vp_rxbuff[rdii];
							rdii++;
							idc++;
					  }
				  #endif
					// 4.int
					#if RX_INT_NUM>0
						idc = (uint32_t)(&(rx_pack_ptr->integers[0]));
					  idl = RX_INT_NUM<<2;
					  for(idi=0;idi<idl;idi++)
					  {
					    if(rdii>=VALUEPACK_BUFFER_SIZE)
					      rdii -= VALUEPACK_BUFFER_SIZE;
					    (*((unsigned char *)idc))= vp_rxbuff[rdii];
							rdii++;
							idc++;
					  }
				  #endif
					// 5.float
					#if RX_FLOAT_NUM>0
						idc = (uint32_t)(&(rx_pack_ptr->floats[0]));
					  idl = RX_FLOAT_NUM<<2;
					  for(idi=0;idi<idl;idi++)
					  {
					    if(rdii>=VALUEPACK_BUFFER_SIZE)
					      rdii -= VALUEPACK_BUFFER_SIZE;
					    (*((unsigned char *)idc))= vp_rxbuff[rdii];
							rdii++;
							idc++;
					  }
				  #endif
				  err = rdii;
					rdIndex+=rx_pack_length;
					isok = 1;
				}else
				{
				  rdIndex++;
			    err++;
				}
			}else
			{ 
		  rdIndex++;
			err++;
		}		
		}else
		{ 
		  rdIndex++;
			err++;
		}		
	}
	last_index = this_index;	
	return isok;
}

void setLED(unsigned char on) {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, on ? GPIO_PIN_SET : GPIO_PIN_RESET);
}
