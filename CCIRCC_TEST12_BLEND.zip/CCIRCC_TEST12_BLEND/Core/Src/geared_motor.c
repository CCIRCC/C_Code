/* motor_control.c */
#include "geared_motor.h"
#include "stm32f1xx_hal.h"

static TIM_HandleTypeDef *motor_htim = NULL;

/* ģ���ʼ�� */
void Motor_Init(TIM_HandleTypeDef *htim)
{
    motor_htim = htim;
    
    /* ����PWM���� */
    if(HAL_TIM_PWM_Start(motor_htim, MOTOR_PWM_CHANNEL) != HAL_OK)
    {
        Error_Handler();
    }
    
    /* ��ʼ״̬��ֹͣ */
    Motor_Stop();
}

/* ����ռ�ձȣ�0~MOTOR_MAX_DUTY�� */
void Motor_SetDuty(uint16_t duty)
{
    if(duty > MOTOR_MAX_DUTY) duty = MOTOR_MAX_DUTY;
    __HAL_TIM_SET_COMPARE(motor_htim, MOTOR_PWM_CHANNEL, duty);
}

/* ��ת */
void Motor_Forward(uint16_t speed)
{
    Motor_SetDuty(speed);
    HAL_GPIO_WritePin(MOTOR_IN1_GPIO, MOTOR_IN1_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(MOTOR_IN2_GPIO, MOTOR_IN2_PIN, GPIO_PIN_RESET);
}

/* ��ת */
void Motor_Backward(uint16_t speed)
{
    Motor_SetDuty(speed);
    HAL_GPIO_WritePin(MOTOR_IN1_GPIO, MOTOR_IN1_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(MOTOR_IN2_GPIO, MOTOR_IN2_PIN, GPIO_PIN_SET);
}

/* ֹͣ */
void Motor_Stop(void)
{
    Motor_SetDuty(0);
    HAL_GPIO_WritePin(MOTOR_IN1_GPIO, MOTOR_IN1_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(MOTOR_IN2_GPIO, MOTOR_IN2_PIN, GPIO_PIN_RESET);
}

