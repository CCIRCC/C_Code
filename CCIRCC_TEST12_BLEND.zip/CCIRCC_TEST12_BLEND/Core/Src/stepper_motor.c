#include "stepper_motor.h"

void Stepper_Init(StepperMotor *motor,
                 GPIO_TypeDef* enable_port, uint16_t enable_pin,
                 GPIO_TypeDef* step_port, uint16_t step_pin,
                 GPIO_TypeDef* dir_port, uint16_t dir_pin)
{
    motor->enable_port = enable_port;
    motor->enable_pin = enable_pin;
    motor->step_port = step_port;
    motor->step_pin = step_pin;
    motor->dir_port = dir_port;
    motor->dir_pin = dir_pin;

    // Ĭ�ϳ�ʼ��״̬
    Stepper_Disable(motor);
    HAL_GPIO_WritePin(motor->dir_port, motor->dir_pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(motor->step_port, motor->step_pin, GPIO_PIN_RESET);
}

void Stepper_Enable(StepperMotor *motor) {
    HAL_GPIO_WritePin(motor->enable_port, motor->enable_pin, GPIO_PIN_RESET);
}

void Stepper_Disable(StepperMotor *motor) {
    HAL_GPIO_WritePin(motor->enable_port, motor->enable_pin, GPIO_PIN_SET);
}

// �������к�������������ƣ�
void Stepper_Run(StepperMotor *motor, uint8_t direction, uint32_t steps)
{
    // ���÷���
    HAL_GPIO_WritePin(motor->dir_port, motor->dir_pin, 
                     direction ? GPIO_PIN_SET : GPIO_PIN_RESET);
    
    // ��������
    for(uint32_t i=0; i<steps; i++){
        HAL_GPIO_WritePin(motor->step_port, motor->step_pin, GPIO_PIN_SET);
        HAL_Delay(1);  // ����ߵ�ƽ����ʱ��
        HAL_GPIO_WritePin(motor->step_port, motor->step_pin, GPIO_PIN_RESET);
        HAL_Delay(1);  // ������ʱ��
    }
}