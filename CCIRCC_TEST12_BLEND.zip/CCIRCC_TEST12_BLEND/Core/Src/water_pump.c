/* water_pump.c */
#include "water_pump.h"
#include "stm32f1xx_hal.h"

/* Private define ---------------------------------------------------------*/
#define WATER_PUMP_TIM        TIM3
#define WATER_PUMP_CHANNEL    TIM_CHANNEL_4
#define WATER_PUMP_GPIO_PORT  GPIOB
#define WATER_PUMP_GPIO_PIN   GPIO_PIN_1
#define WATER_PUMP_GPIO_AF    GPIO_AF2_TIM3

static TIM_HandleTypeDef htim_water_pump;

void water_pump_init(void)
{
    /* 1. ��ʼ��TIM���� */
    htim_water_pump.Instance = WATER_PUMP_TIM;
    htim_water_pump.Init.Prescaler = 72 - 1;          // 72MHz/72 = 1MHz
    htim_water_pump.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim_water_pump.Init.Period = 1000 - 1;           // 1MHz/1000 = 1kHz PWM
    htim_water_pump.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim_water_pump.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    HAL_TIM_PWM_Init(&htim_water_pump);

    /* 2. ����PWMͨ�� */
    TIM_OC_InitTypeDef sConfigOC = {
        .OCMode = TIM_OCMODE_PWM1,
        .Pulse = 0,
        .OCPolarity = TIM_OCPOLARITY_HIGH,
        .OCFastMode = TIM_OCFAST_DISABLE
    };
    HAL_TIM_PWM_ConfigChannel(&htim_water_pump, &sConfigOC, WATER_PUMP_CHANNEL);

    /* 3. ����GPIO */
    GPIO_InitTypeDef GPIO_InitStruct = {
        .Pin = WATER_PUMP_GPIO_PIN,
        .Mode = GPIO_MODE_AF_PP,
        .Speed = GPIO_SPEED_FREQ_LOW,
        .Pull = GPIO_NOPULL
    };
    HAL_GPIO_Init(WATER_PUMP_GPIO_PORT, &GPIO_InitStruct);

    /* 4. ����PWM */
    HAL_TIM_PWM_Start(&htim_water_pump, WATER_PUMP_CHANNEL);
}

void set_water_pump_intensity(int duty)
{
    /* ����ռ�ձȷ�Χ */
    duty = (duty > 1000) ? 1000 : duty;
    
    /* ����PWM����ֵ */
    __HAL_TIM_SET_COMPARE(&htim_water_pump, WATER_PUMP_CHANNEL, duty);
}

