geared_motors\startup_stm32f103xb.o: startup_stm32f103xb.s
