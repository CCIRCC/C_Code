/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define AIN1_M1_Pin GPIO_PIN_0
#define AIN1_M1_GPIO_Port GPIOA
#define AIN2_M1_Pin GPIO_PIN_1
#define AIN2_M1_GPIO_Port GPIOA
#define AIN1_M2_Pin GPIO_PIN_2
#define AIN1_M2_GPIO_Port GPIOA
#define AIN2_M2_Pin GPIO_PIN_3
#define AIN2_M2_GPIO_Port GPIOA
#define STBY1_Pin GPIO_PIN_4
#define STBY1_GPIO_Port GPIOA
#define STBY2_Pin GPIO_PIN_5
#define STBY2_GPIO_Port GPIOA
#define AIN1_M4_Pin GPIO_PIN_6
#define AIN1_M4_GPIO_Port GPIOA
#define AIN2_M4_Pin GPIO_PIN_7
#define AIN2_M4_GPIO_Port GPIOA
#define AIN1_M3_Pin GPIO_PIN_14
#define AIN1_M3_GPIO_Port GPIOB
#define AIN2_M3_Pin GPIO_PIN_15
#define AIN2_M3_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
