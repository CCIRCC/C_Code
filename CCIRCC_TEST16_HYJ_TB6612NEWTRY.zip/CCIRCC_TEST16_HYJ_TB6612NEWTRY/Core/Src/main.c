/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// ���õ��A������ٶ�
// 启动所有PWM和使能TB6612
void Motor_Init() {
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1); // M1
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2); // M2
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3); // M3
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4); // M4
  HAL_GPIO_WritePin(STBY1_GPIO_Port, STBY1_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(STBY2_GPIO_Port, STBY2_Pin, GPIO_PIN_SET);
}
// 控制电机（示例：M1）
void Motor1_Set(int speed) {
  if (speed >= 0) {
    HAL_GPIO_WritePin(AIN1_M1_GPIO_Port, AIN1_M1_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(AIN2_M1_GPIO_Port, AIN2_M1_Pin, GPIO_PIN_RESET);
  } else {
    HAL_GPIO_WritePin(AIN1_M1_GPIO_Port, AIN1_M1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(AIN2_M1_GPIO_Port, AIN2_M1_Pin, GPIO_PIN_SET);
    speed = -speed;
  }
  __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, speed);
}

// 控制电机（示例：M2）
void Motor2_Set(int speed) {
  if (speed >= 0) {
    HAL_GPIO_WritePin(AIN1_M2_GPIO_Port, AIN1_M2_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(AIN2_M2_GPIO_Port, AIN2_M2_Pin, GPIO_PIN_RESET);
  } else {
    HAL_GPIO_WritePin(AIN1_M2_GPIO_Port, AIN1_M2_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(AIN2_M2_GPIO_Port, AIN2_M2_Pin, GPIO_PIN_SET);
    speed = -speed;
  }
  __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, speed);
}

// 控制电机（示例：M3）
void Motor3_Set(int speed) {
  if (speed >= 0) {
    HAL_GPIO_WritePin(AIN1_M3_GPIO_Port, AIN1_M3_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(AIN2_M3_GPIO_Port, AIN2_M3_Pin, GPIO_PIN_RESET);
  } else {
    HAL_GPIO_WritePin(AIN1_M3_GPIO_Port, AIN1_M3_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(AIN2_M3_GPIO_Port, AIN2_M3_Pin, GPIO_PIN_SET);
    speed = -speed;
  }
  __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, speed);
}

// 控制电机（示例：M4）
void Motor4_Set(int speed) {
  if (speed >= 0) {
    HAL_GPIO_WritePin(AIN1_M4_GPIO_Port, AIN1_M4_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(AIN2_M4_GPIO_Port, AIN2_M4_Pin, GPIO_PIN_RESET);
  } else {
    HAL_GPIO_WritePin(AIN1_M4_GPIO_Port, AIN1_M4_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(AIN2_M4_GPIO_Port, AIN2_M4_Pin, GPIO_PIN_SET);
    speed = -speed;
  }
  __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, speed);
}

int constrain(int value, int min, int max) {
  if (value > max) return max;
  if (value < min) return min;
  return value;
}

// 全向移动：输入速度向量(vx, vy)和旋转速度ω
void Mecanum_Move(int vx, int vy, int omega) {
  // 计算各轮速度（根据运动学公式）
  int w1 = vy + vx + omega;  // 左前轮 (M1)
  int w2 = vy - vx - omega;  // 右前轮 (M2)
  int w3 = vy - vx + omega;  // 左后轮 (M3)
  int w4 = vy + vx - omega;  // 右后轮 (M4)

  // 限制速度在PWM范围内（0~999）
  w1 = constrain(w1, -99, 99);
  w2 = constrain(w2, -99, 99);
  w3 = constrain(w3, -99, 99);
  w4 = constrain(w4, -99, 99);

  // 设置电机速度
  Motor1_Set(w1);
  Motor2_Set(w2);
  Motor3_Set(w3);
  Motor4_Set(w4);
}

// 限制函数


// 前进
void MoveForward(int speed) {
  Mecanum_Move(0, speed, 0);
}

// 向右平移
void MoveRight(int speed) {
  Mecanum_Move(speed, 0, 0);
}

// 顺时针旋转
void RotateCW(int speed) {
  Mecanum_Move(0, 0, speed);
}

// 停止
void Brake() {
  Motor1_Set(0);
  Motor2_Set(0);
  Motor3_Set(0);
  Motor4_Set(0);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM4_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
 Motor_Init();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	 
      Mecanum_Move(0,10,0);
		  
		
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
