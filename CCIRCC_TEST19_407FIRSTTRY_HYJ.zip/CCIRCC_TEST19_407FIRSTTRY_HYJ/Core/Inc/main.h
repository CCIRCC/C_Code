/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
typedef struct {
    float vx;    // X���ٶ�
    float vy;    // Y���ٶ�
    float omega; // ��ת���ٶ�
} MotionVector;

typedef struct {
    float Kp, Ki, Kd;     // PID参数
    float target;          // 目标值（如目标速度）
    float integral;        // 积分项
    float last_error;      // 上一次误差
    float output_limit;    // 输出限幅
    float integral_limit;  // 积分限幅
} PIDController;
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define M11_Pin GPIO_PIN_12
#define M11_GPIO_Port GPIOB
#define M12_Pin GPIO_PIN_13
#define M12_GPIO_Port GPIOB
#define M21_Pin GPIO_PIN_14
#define M21_GPIO_Port GPIOB
#define M22_Pin GPIO_PIN_15
#define M22_GPIO_Port GPIOB
#define M31_Pin GPIO_PIN_8
#define M31_GPIO_Port GPIOD
#define M32_Pin GPIO_PIN_9
#define M32_GPIO_Port GPIOD
#define M41_Pin GPIO_PIN_10
#define M41_GPIO_Port GPIOD
#define M42_Pin GPIO_PIN_11
#define M42_GPIO_Port GPIOD

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
