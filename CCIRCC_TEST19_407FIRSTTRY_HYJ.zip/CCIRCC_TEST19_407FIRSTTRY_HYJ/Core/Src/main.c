/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
PIDController pid[4]; // 四个电机的PID实例
MotionVector target_mv = {0}; // 目标运动向量
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// ��ȡ���������壨�ı�Ƶ��
// 设置电机PWM和方向
void Motor_Set(uint8_t motor_id, int16_t speed) {
    uint16_t pin1, pin2;
    GPIO_TypeDef* port;
    TIM_HandleTypeDef* htim;
    uint32_t channel;

    switch (motor_id) {
        case 0: // 电机1
            port = GPIOB;
            pin1 = M11_Pin;
            pin2 = M12_Pin;
            htim = &htim1;
            channel = TIM_CHANNEL_1;
            break;
        case 1: // 电机2
            port = GPIOB;
            pin1 = M21_Pin;
            pin2 = M22_Pin;
            htim = &htim1;
            channel = TIM_CHANNEL_2;
            break;
        case 2: // 电机3
            port = GPIOD;
            pin1 = M31_Pin;
            pin2 = M32_Pin;
            htim = &htim1;
            channel = TIM_CHANNEL_3;
            break;
        case 3: // 电机4
            port = GPIOD;
            pin1 = M41_Pin;
            pin2 = M42_Pin;
            htim = &htim1;
            channel = TIM_CHANNEL_4;
            break;
        default:
            return;
    }

    // 方向控制
    if (speed >= 0) {
        HAL_GPIO_WritePin(port, pin1, GPIO_PIN_SET);
        HAL_GPIO_WritePin(port, pin2, GPIO_PIN_RESET);
    } else {
        HAL_GPIO_WritePin(port, pin1, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(port, pin2, GPIO_PIN_SET);
        speed = -speed;
    }
    // 设置PWM占空比（限制在ARR范围内）
    __HAL_TIM_SET_COMPARE(htim, channel, speed);
}
void PID_Init() {
    for (int i = 0; i < 4; i++) {
        pid[i].Kp = 1.0;  // 根据实际调试调整
        pid[i].Ki = 0.1;
        pid[i].Kd = 0.05;
        pid[i].target = 0;
        pid[i].integral = 0;
        pid[i].last_error = 0;
        pid[i].output_limit = 10000; // 根据PWM的ARR值调整
        pid[i].integral_limit = 1000;
    }
}


float PID_Update(PIDController* pid, float current) {
    float error = pid->target - current;
    
    // 积分项（带限幅）
    pid->integral += error;
    if (pid->integral > pid->integral_limit) pid->integral = pid->integral_limit;
    else if (pid->integral < -pid->integral_limit) pid->integral = -pid->integral_limit;
    
    // 微分项
    float derivative = error - pid->last_error;
    pid->last_error = error;
    
    // 计算输出
    float output = pid->Kp * error + pid->Ki * pid->integral + pid->Kd * derivative;
    
    // 输出限幅
    if (output > pid->output_limit) output = pid->output_limit;
    else if (output < -pid->output_limit) output = -pid->output_limit;
    
    return output;
}

int Read_Encoder(uint8_t TIMX)
{
	int Encoder_TIM;
	switch(TIMX)
	{
	   case 2:  Encoder_TIM = (short)TIM2 -> CNT;  TIM2 -> CNT=0;break;
		 case 3:  Encoder_TIM = (short)TIM3 -> CNT;  TIM3 -> CNT=0;break;	
		 case 4:  Encoder_TIM = (short)TIM4 -> CNT;  TIM4 -> CNT=0;break;	
		 case 5:  Encoder_TIM = (short)TIM5 -> CNT;  TIM5 -> CNT=0;break;
		 default:  Encoder_TIM = 0;
	}
	return Encoder_TIM;
}

int32_t Encoder_GetCount(TIM_HandleTypeDef *htim) {
    int32_t count = (int32_t)__HAL_TIM_GET_COUNTER(htim);
    __HAL_TIM_SET_COUNTER(htim, 0);  // ���������
    return count;
}

// ת�ټ��㣨�������ٱ�30��13�߱�������
float GetRPM(TIM_HandleTypeDef *htim, float sample_time) {
    int32_t pulse = Encoder_GetCount(htim);
    return (pulse * 60) / (13 * 30 * 4 * sample_time);  // RPM = (��������60)/(���������ٱȡ��ı�Ƶ������ʱ��)
}


void Mecanum_Control(MotionVector mv, int32_t *motor_speeds) {
    const float R = 0.1f; // 轮子到中心的距离（单位：米）
    motor_speeds[0] = (int32_t)(-mv.vx + mv.vy + mv.omega * R); // 电机1
    motor_speeds[1] = (int32_t)( mv.vx + mv.vy - mv.omega * R); // 电机2
    motor_speeds[2] = (int32_t)( mv.vx - mv.vy - mv.omega * R); // 电机3
    motor_speeds[3] = (int32_t)(-mv.vx - mv.vy + mv.omega * R); // 电机4
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM5_Init();
  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */
	PID_Init();
target_mv.vx = 50.0f; // 设置目标速度

HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);  // ��ǰ��
HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);  // ��ǰ��
HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);
HAL_TIM_Encoder_Start(&htim5, TIM_CHANNEL_ALL);
HAL_TIM_Base_Start_IT(&htim6); // 启动TIM6中断

HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1); // 电机1 PWM
HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2); // 电机2 PWM
HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3); // 电机1 PWM
HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4); // 电机2 PWM
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	
    Motor_Set(0, 80);
		HAL_Delay(2000); 
    Motor_Set(0, -80);
    HAL_Delay(2000); // 反转2秒
		
		Motor_Set(1, 80);
		HAL_Delay(2000); 
    Motor_Set(1, -80);
    HAL_Delay(2000); // 反转2秒
		
		Motor_Set(2, 80);
		HAL_Delay(2000); 
    Motor_Set(2, -80);
    HAL_Delay(2000); // 反转2秒
		
		Motor_Set(3, 80);
		HAL_Delay(2000); 
    Motor_Set(3, -80);
    HAL_Delay(2000); // 反转2秒
//		int32_t encoder_count = __HAL_TIM_GET_COUNTER(&htim2); // 假设电机1编码器接在TIM2
//printf("Encoder: %ld\r\n", encoder_count);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
// 在main.c中添加：
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if (htim->Instance == TIM6) {
        // 1. 获取目标速度
        int32_t target_speeds[4];
        Mecanum_Control(target_mv, target_speeds);
        
        // 2. 对每个电机进行PID控制
        for (int i = 0; i < 4; i++) {
            // 读取当前速度（假设sample_time为0.01s，即100Hz）
            float current_rpm = GetRPM(&htim2 + i, 0.01); // 注意调整编码器对应的定时器
            
            // 更新PID目标值
            pid[i].target = target_speeds[i];
            
            // 计算PID输出
            float output = PID_Update(&pid[i], current_rpm);
            
            // 设置电机PWM
            Motor_Set(i, (int16_t)output);
        }
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
