
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'CCIRCC_TEST2_HYJ_ENCODED_MOTOR' 
 * Target:  'CCIRCC_TEST2_HYJ_ENCODED_MOTOR' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f10x.h"



#endif /* RTE_COMPONENTS_H */
